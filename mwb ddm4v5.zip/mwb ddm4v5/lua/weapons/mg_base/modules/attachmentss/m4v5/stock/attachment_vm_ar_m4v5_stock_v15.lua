ATTACHMENT.Base = "attachment_vm_ar_mike4_stock_v15"
ATTACHMENT.VElement = {
    Bone = "tag_stock_attach",
    Position = Vector(-0.04, 0, -0.05),
    Angles = Angle(0, 0, 0),
    Offsets = {                    
                    }
}