ATTACHMENT.Base = "att_receiver"
ATTACHMENT.Model = Model("models/weapons/ins2/v_ddm4v5_receiver.mdl")