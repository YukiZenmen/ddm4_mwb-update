ATTACHMENT.Base = "att_magazine"
ATTACHMENT.Model = Model("models/weapons/ins2/v_ddm4v5_mag.mdl")
