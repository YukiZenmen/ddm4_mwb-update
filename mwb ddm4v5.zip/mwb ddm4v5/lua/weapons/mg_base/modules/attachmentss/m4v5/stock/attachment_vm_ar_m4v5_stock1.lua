ATTACHMENT.Base = "att_stock"
ATTACHMENT.Model = Model("models/viper/mw/attachments/mike4/attachment_vm_ar_mike4_stock.mdl")
ATTACHMENT.VElement = {
    Bone = "tag_stock_attach",
    Position = Vector(-0.04, 0, -0.05),
    Angles = Angle(0, 0, 0),
    Offsets = {                    
                    }
}