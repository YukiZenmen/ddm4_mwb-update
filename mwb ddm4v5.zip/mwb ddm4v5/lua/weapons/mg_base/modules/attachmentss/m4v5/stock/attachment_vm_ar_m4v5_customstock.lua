ATTACHMENT.Base = "attachment_vm_ar_mike4_customstock"
ATTACHMENT.VElement = {
    Bone = "tag_barrel_attach",
    Position = Vector(-0.04, -8.375, -0.035),
    Angles = Angle(-0, 0, 0),
    Offsets = {                    
                    }
}