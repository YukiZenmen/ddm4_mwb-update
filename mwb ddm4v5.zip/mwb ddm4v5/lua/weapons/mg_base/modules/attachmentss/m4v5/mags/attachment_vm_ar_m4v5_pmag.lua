ATTACHMENT.Base = "att_magazine"
ATTACHMENT.Name = "30 Round Window PMags"
ATTACHMENT.Model = Model("models/viper/mw/attachments/mike4/attachment_vm_ar_mike4_mag.mdl")
