ATTACHMENT.Base = "att_vm_stock_heavy01"
ATTACHMENT.VElement = {
    Bone = "tag_stock_attach",
    Position = Vector(-0.04, 0, -0.05),
    Angles = Angle(0, 0, 0),
    Offsets = {                    
                    }
}