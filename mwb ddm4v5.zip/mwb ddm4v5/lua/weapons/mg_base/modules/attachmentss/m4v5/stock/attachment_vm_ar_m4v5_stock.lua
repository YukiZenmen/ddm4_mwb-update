ATTACHMENT.Base = "att_stock"
ATTACHMENT.Model = Model("models/weapons/ins2/v_ddm4v5_stock.mdl")